# test_first_component.py
import unittest
from unittest.mock import MagicMock
from first_component import create_list, save_to_database

class TestFirstComponent(unittest.TestCase):

    def test_create_list_normal_case(self):
        # Normal case: doubling each element in the input list
        input_list = [1, 2, 3, 4, 5]
        result = create_list(input_list)
        expected_result = [2, 4, 6, 8, 10]

        # Assert the expected result
        self.assertEqual(result, expected_result)

    def test_create_list_empty_input(self):
        # Corner case: empty input list
        input_list = []
        result = create_list(input_list)
        expected_result = []

        # Assert the expected result for an empty input list
        self.assertEqual(result, expected_result)

    def test_create_list_negative_values(self):
        # Corner case: input list with negative values
        input_list = [-1, -2, -3, -4, -5]
        result = create_list(input_list)
        expected_result = [-2, -4, -6, -8, -10]

        # Assert the expected result for a list with negative values
        self.assertEqual(result, expected_result)

    def test_save_to_database_normal_case(self):
        # Normal case: mock a database and ensure the save method is called correctly
        mock_database = MagicMock()
        my_list = [10, 20, 30, 40, 50]

        # Call the save_to_database function
        save_to_database(my_list, database=mock_database)

        # Assert that the mock database's save method was called once with the correct arguments
        mock_database.save.assert_called_once_with(my_list)

    def test_save_to_database_no_database(self):
        # Corner case: calling save_to_database without providing a database object
        my_list = [10, 20, 30, 40, 50]

        # Use assertLogs to capture log messages (print statements)
        with self.assertLogs() as logs:
            save_to_database(my_list)

        # Assert that a log message indicating saving to the database was captured
        self.assertIn("Saving to database:", logs.output[0])

#python -m unittest test_first_component.py